//
//  UIImage+Blur.h
//  DFPlayer
//
//  Created by Faroe on 2017/9/19.
//  Copyright © 2017年 HDF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Blur)
-(nullable UIImage *)getSubImage:(CGRect)rect;

@end

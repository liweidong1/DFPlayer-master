//
//  DFPlayerRemoteApplication.h
//  DFPlayer
//
//  Created by HDF on 2017/8/10.
//  Copyright © 2017年 HDF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DFPlayerRemoteApplication : UIApplication

@end
